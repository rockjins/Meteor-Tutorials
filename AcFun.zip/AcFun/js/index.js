

//顶部二维码划入划出显示
function downLoadApp() {
	$(".download span").hover(function(e) {
		$(".download img").show();
	}, function(e) {
		$(".download img").hide();
	})
}

//显示上传列表
function uploadMenu() {
	var timer;
	var up = $("#upload");
	up.hover(function(e) {
		//划入清除延迟调用
		clearTimeout(timer);
		$(".upload").show();
	}, function(e) {
		//划出延迟调用隐藏函数，更好的用户体验
		timer = setTimeout(function() {
			$(".upload").hide();
		}, 300)
	})
}


//导航菜单的子菜单项ajax调用信息
function navSubMenuInfo(index){
	$.getJSON("json/main.json",function(e){
		var thisSubMenu =e.nav[index];
		for (var i in thisSubMenu) {
			$(".submenu li").eq((i-1)).find("a").text(thisSubMenu[i]);
		}
	})
}

//导航下面的小方块跟随鼠标,并让子菜单显示
function navTip() {
	//获取到主菜单
	var nav = $("#nav-list");
	//获取到子菜单
	var submenu = $(".nav-inner ul").eq(1).parent();
	var timer=null;
	var ajaxTimer=null;
	nav.on("mouseover", "li", function(e) {
		//鼠标移入先关闭定时器，避免冲突
		clearTimeout(timer);
		//停止当前正在运动的span标签
		nav.find("span").stop();
		//让所有导航项字体变为初始颜色，除了带light类的
		$("#nav-list li a").not(".nav-light").css({
				color: "#333"
			})
			//让当前选择的导航项字体高亮
		$(this).find("a").css({
				color: "#fd4c5d"
			})
			//让span滑动到当前选择的导航项位置
		nav.find("span").animate({
				left: (this.offsetLeft - 10)
			})
		//调用ajax，获取当前子菜单的内容
		$(".main-menu li").mouseover(function(e){
			//只有当鼠标在主菜单滑动时才调用ajax
			var i = $(this).index();
			if (!ajaxTimer) {
				navSubMenuInfo(i);
			}
			clearTimeout(ajaxTimer);
			ajaxTimer=setTimeout(function(){
				navSubMenuInfo(i);
			},200)
		})
		
		
		
			//让子菜单显示
		submenu.show();
	})
	nav.on("mouseout", "#nav-list li", function(e) {
		//延迟调用，增强用户体验
		timer = setTimeout(function() {
			//防止动画冲突，清除span正在进行的动画
			nav.find("span").stop();
			//让除了有light类的导航项字体全部变为初始颜色
			$("#nav-list li a").not(".nav-light").css({
					color: "#333"
				})
				//让span运动到默认激活的导航项
			nav.find("span").animate({
					left: ($("#nav-list .nav-light").parent().get(0).offsetLeft - 10)
				})
				//让子菜单隐藏
			submenu.hide();
		}, 700)
	})
}

//这是一个全局变量，用来控制banner切换的定时器，因为考虑到底下的小圆点也要控制定时器，所以
//迫不得已设了一个全局变量！
var bannerTimer;
//banner的切换
function changeBanner(index) {
	var scroll = $("#scroll-banner");
	//设定src的初始值
	var i = 1;
	var list = $("#scroll-list li");
	//index为底下选择列表的索引值
	//让选择列表的颜色随banner索引变色
	list.eq(((index - 1) || (i - 1))).css({
			backgroundColor: "#fd4c5b"
		}).siblings().css({
			backgroundColor: "#fff"
		})
		//如果index存在，则把index赋值给i
	if (index) {
		i = index;
	}
	//设置一个定时器重复滚动bannner
	bannerTimer = setInterval(function() {
		//i为src的值
		i++;
		//先让banner图片隐藏
		scroll.find("img").fadeOut(300, function() {
			//一下判断为banner当前的文字描述
			if (i > 3) {
				i = 1;
			}
			if (i == 1) {
				$(".scroll-dis").html("第11话 铁の纳");
			} else if (i == 2) {
				$(".scroll-dis").html("怪蜀黍和小妹妹");
			} else {
				$(".scroll-dis").html("初音未来：十周年！");
			}
			//改变选择列表的颜色
			list.eq((i - 1)).css({
					backgroundColor: "#fd4c5b"
				}).siblings().css({
					backgroundColor: "#fff"
				})
				//改变src的值
			scroll.find("img").attr("src", "img/scroll" + i + ".jpg");
		});
		//让图片显示
		scroll.find("img").fadeIn(300);
		//清空index，这一步很重要！
		index = undefined;

	}, 2000)
}

//控制banner的小圆点
function ctrlBannerList() {
	var Alllist = $("#scroll-list");
	var list = $("#scroll-list li");
	var scroll = $("#scroll-banner");
	var index;
	list.on("click", function(e) {
		//清除changeBanner方法中的定时器，增强用户体验
		clearInterval(bannerTimer);
		//获取当前点击的列表项的索引值
		index = $(this).index();
		//以下判断为banner页的文字描述
		if (index == 0) {
			$(".scroll-dis").html("第11话 铁の纳");
		} else if (index == 1) {
			$(".scroll-dis").html("怪蜀黍和小妹妹");
		} else {
			$(".scroll-dis").html("初音未来：十周年！");
		}
		//改变选择项的背景颜色与图片同步
		$(this).css({
				backgroundColor: "#fd4c5b"
			}).siblings().css({
				backgroundColor: "#fff"
			})
			//改变banner图片的src
		scroll.find("img").attr("src", "img/scroll" + (index + 1) + ".jpg");
		//调用changeBanner方法，传入当前选择项的索引值
		changeBanner((index + 1));
		//阻止事件冒泡
		e.stopPropagation();
	})
}

//引入脚部html文件
function loadFooter() {
	$.get("public/footer.html", function(e) {
		$("#footer").append(e);
	})
}



//给需要加蒙层的图片加上蒙层
function mask1(obj,t,l){
	//先创建一个蒙层
	var oMask =$("<div><p class='w'>Some introduce...</p></div>");
	//获取制定图片的宽高
	var objHeight = obj.height();
	var objWidth = obj.width();
	//设置蒙层的宽高和图片同步
	oMask.height(objHeight);
	oMask.width(objWidth);
	//设置蒙层样式
	oMask.css({
		backgroundColor:"rgba(0,0,0,0.5)",
		position:"absolute",
		top:t,
		left:l,
		zIndex:5,
		display:"none",
		cursor:"pointer",
		borderRadius:"10px",
		textAlign:"center"
	})
	//插入蒙层
	obj.parent().parent().css({
		position:"relative"
	}).append(oMask);
	//鼠标划入显示/隐藏蒙层
	obj.mouseover(function(){
		oMask.stop();
		oMask.fadeIn(300);
	})
	oMask.mouseout(function(){
		oMask.stop()
		oMask.fadeOut(300);
	})
}
//用ajax调用essay的文件
function essayInfo(){
	$.get("public/essay.html",function(e){
		$(".banana-essay-news").append(e);
	})
}
//给essay添加导航滑动的一系列动作
function essayNav(){
	//获取到导航栏上的每一项
	var main = $(".banana-essay-menu li a");
	main.on("mouseover",function(e){
		//获取到底下的小滑块
		var move = $(".banana-essay-target");
		//先停止小滑块当前的动画，增强用户体验
		move.stop();
		//获取到当前滑动的导航项的索引值
		var index = $(this).parent().index();
		//通过索引值用ajax调用不同栏目的信息
		essayAjax(index);
		//让当前选项变色
		$(this).parent().siblings().find("a").removeClass()
		.end().end().end().addClass("banana-essay-active");
		//移动滑块，匹配当前选项
		var l = this.offsetLeft
		move.animate({
			left:l
		})
	})
}
//essay下不同的栏目ajax调用
function essayAjax(index){
	$.getJSON("json/main.json",function(e){
		var essayJson = e.essay
		$(".banana-essay-news-active img").attr({
			src:essayJson[index].src
		})
		$(".banana-essay-news-active").siblings().find("a").html(essayJson[index].info);
	})
}

//验证cookie是否存在
function checkCookie(){
	var cook=$.cookie("customer");
	if (cook) {
		var cookarr = cook.split("&");
		$(".login").find("a").attr("href","collect/collect.html")
		.html("<span>"+cookarr[2]+"</span>的房间");
	}
}

//滚动时，楼层按钮同步变换颜色
function scrollChangeColor(i){
	var doc = $(document);
	var one = $(".monkey")[0].offsetTop;
	var two = $(".banana")[0].offsetTop;
	var three = $(".fish")[0].offsetTop;
	var li = $(".scrollto li");
	if (i==1) {
		doc.trigger("scroll");
	}
	doc.scroll(function(e){
		var t = doc.scrollTop()+50;
		if (t>=0&&t<one) {
			li.removeClass().eq(0).addClass("scroll-active");
		}else if (t>=one&&t<two) {
			li.removeClass().eq(1).addClass("scroll-active");
		}else if (t>=two&&t<three) {
			li.removeClass().eq(2).addClass("scroll-active");
		}else if (t>=three) {
			li.removeClass().eq(3).addClass("scroll-active");
		}
	})
}
//点击右侧列表跳转楼层
function scrollTop(){
	var doc = $(document);
	var one = $(".monkey")[0].offsetTop-50;
	var two = $(".banana")[0].offsetTop-50;
	var three = $(".fish")[0].offsetTop-50;
	var scrollarr = [0,one,two,three];
	var li = $(".scrollto li");
	li.click(function(e){
		var i = $(this).index();
		doc.scrollTop(scrollarr[i]);
		scrollChangeColor(1);
	})
}
//banner提示
function activityPage(){
	var banner = $(".banner-temp");
	var ad = $("#banner-ad")
	banner.mousemove(function(e){
		ad.show().css({
			left:e.pageX+10,
			top:e.pageY+10
		})
	});
	banner.mouseout(function(e){
		ad.hide();
	});
	banner.click(function(){
		window.location.href="activity/activity.html";
	})
}




$(function() {
	downLoadApp();
	uploadMenu();
	navTip();
	changeBanner();
	ctrlBannerList();
	loadFooter();
	scrollChangeColor();
	scrollTop();
})
window.onload=function(){
	mask1(($("#newboot1")),30,15);
	mask1(($("#newboot2")),30,15);
	mask1($("#monkey1"),0,0);
	mask1($("#monkey2"),0,0);
	mask1($("#monkey3"),0,0);
	mask1($("#monkey4"),0,0);
	mask1($("#banana1"),0,0);
	mask1($("#banana2"),0,0);
	mask1($("#banana3"),0,0);
	mask1($("#banana4"),0,0);
	mask1($("#banana5"),0,0);
	mask1($("#banana6"),0,0);
	mask1($("#banana7"),0,0);
	mask1($("#banana8"),0,0);
	essayInfo();
	essayNav();
	essayAjax(0);
	checkCookie();
	activityPage();
}















