//获取头部
function loadTop() {
	$.get("../public/login_sign_top.html", function(e) {
		$("body").prepend(e);
	})
}

//获取脚部
function loadFooter() {
	$.get("../public/footer.html", function(e) {
		$("#footer").append(e);
	})
}
//初始化表格语言
Highcharts.setOptions({
    lang:{
       contextButtonTitle:"图表导出菜单",
       decimalPoint:".",
       downloadJPEG:"下载JPEG文件",
       downloadPDF:"下载PDF文件",
       downloadPNG:"下载PNG文件",
       downloadSVG:"下载SVG文件",
       drillUpText:"返回 {series.name}",
       loading:"加载中",
       months:["一月","二月","三月","四月","五月","六月","七月","八月","九月","十月","十一月","十二月"],
       noData:"没有数据",
       numericSymbols: [ "千" , "兆" , "G" , "T" , "P" , "E"],
       printChart:"打印图表",
       resetZoom:"恢复缩放",
       resetZoomTitle:"恢复图表",
       shortMonths: [ "Jan" , "Feb" , "Mar" , "Apr" , "May" , "Jun" , "Jul" , "Aug" , "Sep" , "Oct" , "Nov" , "Dec"],
       thousandsSep:",",
       weekdays: ["星期一", "星期二", "星期三", "星期三", "星期四", "星期五", "星期六","星期天"]
    }
});


//制作图表
function chars() {
	$.getJSON("../json/chars.json", function(e) {
		$('#container').highcharts({
			chart:{
				zoomType:"x",
				panning:true,
				panKey:"shift"
			},
			title: {
				text: 'Acfun浏览量统计',
				x: -20
			},
			subtitle: {
				text: '每天10点刷新',
				x: -20
			},
			xAxis: {
				categories: ['0-2点', '2-4点', '4-6点', '6-8点', '8-10点', '10-12点', '12-14点', '14-16点', '16-18点', '18-20点', '20-22点', '22-14点']
			},
			yAxis: {
				title: {
					text: '浏览次数'
				},
				plotLines: [{
					value: 0,
					width: 1,
					color: '#808080'
				}],
				labels:{
					formatter: function() {
								if (this.value <= 600) {
									return "低峰期(" + this.value + ")";
								} else if (this.value > 600 && this.value <= 1600) {
									return "正常(" + this.value + ")";
								} else {
									return "高峰期(" + this.value + ")";
								}
							}
				}
			},
			tooltip: {
				valueSuffix: '次'
			},
			legend: {
				layout: 'vertical',
				align: 'right',
				verticalAlign: 'middle',
				borderWidth: 0,
				labelFormatter: function() {
   				return  this.name/* + '(点击隐藏/显示)'*/;
				}},
			series: e,
			credits: {
				enabled: false
			}
		});
	})
}

$(function() {
	loadFooter();
	loadTop();
	chars();
})