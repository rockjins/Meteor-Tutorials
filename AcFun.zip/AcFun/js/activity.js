
//获取头部
function loadTop(){
	$.get("../public/login_sign_top.html",function(e){
		$("body").prepend(e);
	})
}

//获取脚部
function loadFooter() {
	$.get("../public/footer.html", function(e) {
		$("#footer").append(e);
	})
}

$(function(){
	loadFooter();
	loadTop();
})
