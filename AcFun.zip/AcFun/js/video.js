
	//获取头部
function loadTop() {
	$.get("../public/login_sign_top.html", function(e) {
		$("body").prepend(e);
	})
}

//获取脚部
function loadFooter() {
	$.get("../public/footer.html", function(e) {
		
		$("#footer").append(e);
	})
}
//生成弹幕
function creatBar(){
	//获取发射按钮
	var shot = $(".shot");
	//获取视频元素
	var v = $("#video")
	//获取输入框
	var value = $("#input-main");
	//获取到视频元素的宽高
	var vW = v.width();
	//点击发射调用方法
	shot.click(function(e){
		//创建一个弹幕元素
		var span = $("<span class='runspan'></span>");
		//设置css样式
		span.css({
			position:"absolute",
			top: randomTop(),
			left:vW,
			color:randomColor(),
			overflow: "hidden",
			display:"block",
			fontSize:"20px",
			whiteSpace:"pre",
			fontWeight:600
		}).html(value.val()).appendTo(v);
		//获取span的宽度，传入运动方法，让sapn到目的地删除
		var spanW = (span[0].innerHTML.length)*20;
		barRun(spanW,span);
		//清空输入框，增强用户体验
		value.val("");
	})
	//按回车也能调用方法
	value.keyup(function(e){
		if (e.keyCode==13) {
			shot.trigger("click");
		}
	})
}
//生成一个随机的Top值
function randomTop(){
	var v = $("#video");
	var vH = v.height();
	var ram = parseInt(Math.random()*(vH-100)+50);
	return ram;
}
//生成一个随机的color值
function randomColor(){
	var color1=parseInt(Math.random()*256);
	var color2=parseInt(Math.random()*256);
	var color3=parseInt(Math.random()*256);
	return "rgb("+color1+","+color2+","+color3+")";
}
//让元素运动
function barRun(width,run){
	//随机的速度
	var randomSpeed = (Math.random()*3000)+5000;
	run.animate({
		left:-(width)
	},randomSpeed,"linear",function(){
		$(this).remove();
	})
}



$(function() {
		loadFooter();
		loadTop();
		creatBar();
	})



