

//获取头部
function loadTop(){
	$.get("../public/login_sign_top.html",function(e){
		$("body").prepend(e);
	})
}

//获取脚部
function loadFooter() {
	$.get("../public/footer.html", function(e) {
		$("#footer").append(e);
	})
}
//ajax引入item页面
function ajaxItem(){
	$.get("html/item.html",function(e){
		$(".main-right-main").append(e);
		$(".main-right-main").slideDown(1000);
		$(".collect-item").slideDown(1000);
		$("#drag").sortable({
			revert:500,
			cursor:"move"
		}).disableSelection();
	});
}
//删除收藏项目的删除框显示/隐藏
function deleItemShow(){
	var item = $(".collect-item");
	var alter = $(".alter");
	item.hover(function(e){
		$(this).find(".alter").show();
	},function(e){
		$(this).find(".alter").hide();
	})
}
//点击删除项目
function deleItem (){
	var alter = $(".alter").find("a");
	alter.click(function(e){
		$(this).parent().parent().hide(300)
	})
}
//点击签到
function signIn(){
	$(".btn").click(function(){
		$(this).find("a").css({
			backgroundColor:"orange",
			color:"#f1f1f1",
			cursor:"not-allowed"
		}).html("签到成功");
	})
}
//获取cookie
function getCookie(){
	var cook = $.cookie("customer");
	if (cook) {
		var cookarr = cook.split("&");
		$(".username").find("span").html("欢迎回来，"+cookarr[2]);
	}
}
//头像旋转
function rotateHead(){
	$(".head").hover(function(){
		$(this).rotate({
			animateTo:720
		})
	},function(){
		$(this).rotate({
			animateTo:-720
		})
	})
}

$(function(){
	loadFooter();
	loadTop();
	ajaxItem();
	signIn();
	getCookie();
	setTimeout(function(){
		deleItemShow();
		deleItem ();
	},100)
	rotateHead();
})
