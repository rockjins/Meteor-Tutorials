
	//获取头部
function loadTop() {
	$.get("../public/login_sign_top.html", function(e) {
		$("body").prepend(e);
	})
}

//获取脚部
function loadFooter() {
	$.get("../public/footer.html", function(e) {
		$("#footer").append(e);
	})
}
//验证用户名是否符合格式

var bool1;
function checkUser(i) {
	var regUser = /^[a-zA-z][a-zA-Z0-9_]{5,11}$/;
	//用户名由 6-12位的字母下划线和数字组成,只能以字母开头
	if (i==1) {
			$("#username").trigger("keyup");
		}
	$("#username").on("keyup", function() {
		var name = $("#username").val();
		if (!regUser.test(name)) {
			$(".userright").hide(300);
			$("#userwaning").show(300);
			bool1=false;
		} else {
			$("#userwaning").hide(300);
			$(".userright").show(300);
			bool1=true;
		}
		
	});
	return bool1;
}
//验证密码是否符合格式
var bool2;
function checkPassword(i) {
	var regPass = /^[0-9|A-Z|a-z]{6,16}$/;
	//密码只能包含字母数字，且长度为6~16位
		if (i==1) {
			$("#pwd").trigger("keyup");
		}
	$("#pwd").on("keyup", function() {
		var pwd = $("#pwd").val();
		if (!regPass.test(pwd)) {
			$(".pwdright").hide(300);
			$("#passwaning").show(300);
			bool2=false;
		} else {
			$("#passwaning").hide(300);
			$(".pwdright").show(300);
			bool2 = true;
		}
	});
	
		return bool2;
}
//验证账号密码是否正确
function checkCustomer(){
	var username = $("#username").val();
	var pwd = $("#pwd").val();
	var cook = $.cookie("customer");
	if (cook) {
		var cookarr = cook.split("&");
		if ((cookarr[0]==username)&&(cookarr[1]==pwd)) {
			return true;
		}else{
			$("#customerwarning").show(500);
			setTimeout(function(){
			$("#customerwarning").hide(500);
			},2500)
			return false;
		}
	}else{
			$("#customerwarning").show(500);
			setTimeout(function(){
			$("#customerwarning").hide(500);
			},2500)
			return false;
		}
	
}

var code ; //在全局定义验证码   
//产生验证码  
function createCode(){  
     code = "";   
     var codeLength = 4;//验证码的长度  
     var checkCode = document.getElementById("code");   
     var random = new Array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R',  
     'S','T','U','V','W','X','Y','Z');//随机数  
     for(var i = 0; i < codeLength; i++) {//循环操作  
        var index = Math.floor(Math.random()*36);//取得随机数的索引（0~35）  
        code += random[index];//根据索引取得随机数加到code上  
    }  
    checkCode.value = code;//把code值赋给验证码  
}  
//校验验证码
var bool6;
function validate(i){
	if (i==1) {
		$("#codename").trigger("keyup");
	}
	$("#codename").on("keyup", function() {
    var inputCode = $("#codename").val().toUpperCase(); //取得输入的验证码并转化为大写       
    if(inputCode != code ) { //若输入的验证码与产生的验证码不一致时  
        $(".coderight").hide(300);
        $(".codewaning").show(300);
        bool6 = false;
    }         
    else {
    	$(".coderight").show(300);
        $(".codewaning").hide(300);
        bool6=true;
    }             
} 
	);
	return bool6;
}





//验证登陆界面跳转
function loginTo(){
	$(".login-btn").on("click",function(){
		//再次调用检测功能，确定全部检测合格再提交
		if (checkUser(1)&&checkPassword(1)&&validate(1)) {
			if (checkCustomer()) {
				$(".login-btn").attr({
					"href":"../index.html"
				})
			}
		}else{
			$(".login-btn").attr({
				"href":"#"
			})
		}
	})
}


$(function() {
		loadFooter();
		loadTop();
		checkUser();
		checkPassword();
		loginTo();
		createCode();
		validate();
	})