var z = new Object();
z.prototype.big=function(imgURL,){
	
}
